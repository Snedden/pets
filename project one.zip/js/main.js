$(window).load(function(){
petObj=new Pets();
});